﻿namespace Installer.Core.Patching
{
    public enum TargetPartition
    {
        Boot,
        Windows,
    }
}